local _ENV = mkmodule('plugins.pathable')

--[[

Native functions: (see Plugins.rst for details)

- paintScreen(cursor[,skip_unrevealed])

]]

return _ENV
