local _ENV = mkmodule('plugins.liquids')

--[[

 Native functions:

 * paint(pos,brush,paint,amount,size,setmode,flowmode)

--]]

return _ENV