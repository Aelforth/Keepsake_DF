local _ENV = mkmodule('plugins.rename')

--[[

 Native functions:

 * canRenameBuilding(building)
 * isRenamingBuilding(building)
 * renameBuilding(building, name)

--]]

return _ENV