local _ENV = mkmodule('plugins.power-meter')

--[[

 Native functions:

 * makePowerMeter(plate_info,min_power,max_power,invert)

--]]

return _ENV