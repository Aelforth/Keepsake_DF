local _ENV = mkmodule('plugins.zone')

--[[

 Native functions:

 * autobutcher_isEnabled()
 * autowatch_isEnabled()

--]]

return _ENV