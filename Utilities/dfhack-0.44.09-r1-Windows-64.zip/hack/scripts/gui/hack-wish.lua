--@ alias = 'gui/create-item'
--[====[

gui/hack-wish
=============
An alias for `gui/create-item`.  Deprecated.

]====]