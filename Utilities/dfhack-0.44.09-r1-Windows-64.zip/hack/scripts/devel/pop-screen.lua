-- For killing bugged out gui script screens.
--[====[

devel/pop-screen
================
For killing bugged out gui script screens.

]====]

dfhack.screen.dismiss(dfhack.gui.getCurViewscreen())
