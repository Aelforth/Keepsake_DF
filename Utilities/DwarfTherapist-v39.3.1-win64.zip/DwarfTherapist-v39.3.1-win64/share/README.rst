VIEWS
=====
Add a new file in gridviews with a .dtg extension. Files are loaded in order by name.

GAME DATA
=====
The game_data.ini also contains titles and definitions for labors, jobs, thoughts, attributes, default roles etc.

To override the default game_data.ini, a modified version should be placed here with the desired changes. The original game_data.ini can be found in the repository in the resources directory.
